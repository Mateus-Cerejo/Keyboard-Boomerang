function outline_with_holes_extrude_1_2_outline_fn(){
    return new CSG.Path2D([[285.8,-111.6],[338.4,-111.6]]).appendPoint([338.4,-92.4]).appendPoint([357.6,-92.4]).appendPoint([357.6,-69.2]).appendPoint([338.4,-69.2]).appendPoint([338.4,-50]).appendPoint([257.6,-50]).appendPoint([257.6,-69.2]).appendPoint([238.4,-69.2]).appendPoint([238.4,-117.2]).appendPoint([205.7,-117.2]).appendPoint([205.7,-178.8]).appendPoint([228.9,-178.8]).appendPoint([228.9,-140.4]).appendPoint([285.8,-140.4]).appendPoint([285.8,-111.6]).close().innerToCAG()
.subtract(
    CAG.circle({"center":[222.3,-157.6],"radius":1.3})
.union(
    CAG.circle({"center":[259.6,-129.3],"radius":1.3})
).union(
    CAG.circle({"center":[312.6,-90.4],"radius":1.3})
).union(
    CAG.circle({"center":[331.8,-71.2],"radius":1.3})
).union(
    CAG.circle({"center":[293.4,-71.2],"radius":1.3})
).union(
    CAG.circle({"center":[259.6,-81.3],"radius":1.3})
).union(
    CAG.circle({"center":[245,-100],"radius":1.3})
).union(
    new CSG.Path2D([[243.1,-87.7],[256.9,-87.7]]).appendPoint([256.9,-73.9]).appendPoint([243.1,-73.9]).appendPoint([243.1,-87.7]).close().innerToCAG()
).union(
    new CSG.Path2D([[262.3,-135.7],[276.1,-135.7]]).appendPoint([276.1,-121.9]).appendPoint([262.3,-121.9]).appendPoint([262.3,-135.7]).close().innerToCAG()
).union(
    new CSG.Path2D([[243.1,-135.7],[256.9,-135.7]]).appendPoint([256.9,-121.9]).appendPoint([243.1,-121.9]).appendPoint([243.1,-135.7]).close().innerToCAG()
).union(
    new CSG.Path2D([[219.15,-135.7],[232.95,-135.7]]).appendPoint([232.95,-121.9]).appendPoint([219.15,-121.9]).appendPoint([219.15,-135.7]).close().innerToCAG()
).union(
    new CSG.Path2D([[339.1,-87.7],[352.9,-87.7]]).appendPoint([352.9,-73.9]).appendPoint([339.1,-73.9]).appendPoint([339.1,-87.7]).close().innerToCAG()
).union(
    new CSG.Path2D([[319.9,-68.5],[333.7,-68.5]]).appendPoint([333.7,-54.7]).appendPoint([319.9,-54.7]).appendPoint([319.9,-68.5]).close().innerToCAG()
).union(
    new CSG.Path2D([[319.9,-87.7],[333.7,-87.7]]).appendPoint([333.7,-73.9]).appendPoint([319.9,-73.9]).appendPoint([319.9,-87.7]).close().innerToCAG()
).union(
    new CSG.Path2D([[319.9,-106.9],[333.7,-106.9]]).appendPoint([333.7,-93.1]).appendPoint([319.9,-93.1]).appendPoint([319.9,-106.9]).close().innerToCAG()
).union(
    new CSG.Path2D([[300.7,-68.5],[314.5,-68.5]]).appendPoint([314.5,-54.7]).appendPoint([300.7,-54.7]).appendPoint([300.7,-68.5]).close().innerToCAG()
).union(
    new CSG.Path2D([[300.7,-87.7],[314.5,-87.7]]).appendPoint([314.5,-73.9]).appendPoint([300.7,-73.9]).appendPoint([300.7,-87.7]).close().innerToCAG()
).union(
    new CSG.Path2D([[300.7,-106.9],[314.5,-106.9]]).appendPoint([314.5,-93.1]).appendPoint([300.7,-93.1]).appendPoint([300.7,-106.9]).close().innerToCAG()
).union(
    new CSG.Path2D([[281.5,-68.5],[295.3,-68.5]]).appendPoint([295.3,-54.7]).appendPoint([281.5,-54.7]).appendPoint([281.5,-68.5]).close().innerToCAG()
).union(
    new CSG.Path2D([[281.5,-87.7],[295.3,-87.7]]).appendPoint([295.3,-73.9]).appendPoint([281.5,-73.9]).appendPoint([281.5,-87.7]).close().innerToCAG()
).union(
    new CSG.Path2D([[281.5,-106.9],[295.3,-106.9]]).appendPoint([295.3,-93.1]).appendPoint([281.5,-93.1]).appendPoint([281.5,-106.9]).close().innerToCAG()
).union(
    new CSG.Path2D([[262.3,-68.5],[276.1,-68.5]]).appendPoint([276.1,-54.7]).appendPoint([262.3,-54.7]).appendPoint([262.3,-68.5]).close().innerToCAG()
).union(
    new CSG.Path2D([[262.3,-87.7],[276.1,-87.7]]).appendPoint([276.1,-73.9]).appendPoint([262.3,-73.9]).appendPoint([262.3,-87.7]).close().innerToCAG()
).union(
    new CSG.Path2D([[262.3,-106.9],[276.1,-106.9]]).appendPoint([276.1,-93.1]).appendPoint([262.3,-93.1]).appendPoint([262.3,-106.9]).close().innerToCAG()
).union(
    new CSG.Path2D([[210.4,-154.9],[224.2,-154.9]]).appendPoint([224.2,-141.1]).appendPoint([210.4,-141.1]).appendPoint([210.4,-154.9]).close().innerToCAG()
).union(
    new CSG.Path2D([[210.4,-174.1],[224.2,-174.1]]).appendPoint([224.2,-160.3]).appendPoint([210.4,-160.3]).appendPoint([210.4,-174.1]).close().innerToCAG()
)).union(
    new CSG.Path2D([[65.6,-111.6],[118.2,-111.6]]).appendPoint([118.2,-140.4]).appendPoint([175.1,-140.4]).appendPoint([175.1,-178.8]).appendPoint([198.3,-178.8]).appendPoint([198.3,-117.2]).appendPoint([165.6,-117.2]).appendPoint([165.6,-69.2]).appendPoint([146.4,-69.2]).appendPoint([146.4,-50]).appendPoint([65.6,-50]).appendPoint([65.6,-69.2]).appendPoint([46.4,-69.2]).appendPoint([46.4,-92.4]).appendPoint([65.6,-92.4]).appendPoint([65.6,-111.6]).close().innerToCAG()
.subtract(
    CAG.circle({"center":[191.7,-157.6],"radius":1.3})
.union(
    CAG.circle({"center":[82.2,-90.4],"radius":1.3})
).union(
    CAG.circle({"center":[67.6,-81.3],"radius":1.3})
).union(
    CAG.circle({"center":[101.4,-71.2],"radius":1.3})
).union(
    CAG.circle({"center":[144.4,-129.3],"radius":1.3})
).union(
    CAG.circle({"center":[144.4,-81.3],"radius":1.3})
).union(
    CAG.circle({"center":[159,-100],"radius":1.3})
).union(
    new CSG.Path2D([[70.3,-68.5],[84.1,-68.5]]).appendPoint([84.1,-54.7]).appendPoint([70.3,-54.7]).appendPoint([70.3,-68.5]).close().innerToCAG()
).union(
    new CSG.Path2D([[70.3,-87.7],[84.1,-87.7]]).appendPoint([84.1,-73.9]).appendPoint([70.3,-73.9]).appendPoint([70.3,-87.7]).close().innerToCAG()
).union(
    new CSG.Path2D([[70.3,-106.9],[84.1,-106.9]]).appendPoint([84.1,-93.1]).appendPoint([70.3,-93.1]).appendPoint([70.3,-106.9]).close().innerToCAG()
).union(
    new CSG.Path2D([[89.5,-68.5],[103.3,-68.5]]).appendPoint([103.3,-54.7]).appendPoint([89.5,-54.7]).appendPoint([89.5,-68.5]).close().innerToCAG()
).union(
    new CSG.Path2D([[89.5,-87.7],[103.3,-87.7]]).appendPoint([103.3,-73.9]).appendPoint([89.5,-73.9]).appendPoint([89.5,-87.7]).close().innerToCAG()
).union(
    new CSG.Path2D([[89.5,-106.9],[103.3,-106.9]]).appendPoint([103.3,-93.1]).appendPoint([89.5,-93.1]).appendPoint([89.5,-106.9]).close().innerToCAG()
).union(
    new CSG.Path2D([[108.7,-68.5],[122.5,-68.5]]).appendPoint([122.5,-54.7]).appendPoint([108.7,-54.7]).appendPoint([108.7,-68.5]).close().innerToCAG()
).union(
    new CSG.Path2D([[108.7,-87.7],[122.5,-87.7]]).appendPoint([122.5,-73.9]).appendPoint([108.7,-73.9]).appendPoint([108.7,-87.7]).close().innerToCAG()
).union(
    new CSG.Path2D([[108.7,-106.9],[122.5,-106.9]]).appendPoint([122.5,-93.1]).appendPoint([108.7,-93.1]).appendPoint([108.7,-106.9]).close().innerToCAG()
).union(
    new CSG.Path2D([[51.1,-87.7],[64.9,-87.7]]).appendPoint([64.9,-73.9]).appendPoint([51.1,-73.9]).appendPoint([51.1,-87.7]).close().innerToCAG()
).union(
    new CSG.Path2D([[127.9,-135.7],[141.7,-135.7]]).appendPoint([141.7,-121.9]).appendPoint([127.9,-121.9]).appendPoint([127.9,-135.7]).close().innerToCAG()
).union(
    new CSG.Path2D([[147.1,-135.7],[160.9,-135.7]]).appendPoint([160.9,-121.9]).appendPoint([147.1,-121.9]).appendPoint([147.1,-135.7]).close().innerToCAG()
).union(
    new CSG.Path2D([[171.05,-135.7],[184.85,-135.7]]).appendPoint([184.85,-121.9]).appendPoint([171.05,-121.9]).appendPoint([171.05,-135.7]).close().innerToCAG()
).union(
    new CSG.Path2D([[127.9,-68.5],[141.7,-68.5]]).appendPoint([141.7,-54.7]).appendPoint([127.9,-54.7]).appendPoint([127.9,-68.5]).close().innerToCAG()
).union(
    new CSG.Path2D([[127.9,-87.7],[141.7,-87.7]]).appendPoint([141.7,-73.9]).appendPoint([127.9,-73.9]).appendPoint([127.9,-87.7]).close().innerToCAG()
).union(
    new CSG.Path2D([[127.9,-106.9],[141.7,-106.9]]).appendPoint([141.7,-93.1]).appendPoint([127.9,-93.1]).appendPoint([127.9,-106.9]).close().innerToCAG()
).union(
    new CSG.Path2D([[147.1,-87.7],[160.9,-87.7]]).appendPoint([160.9,-73.9]).appendPoint([147.1,-73.9]).appendPoint([147.1,-87.7]).close().innerToCAG()
).union(
    new CSG.Path2D([[179.8,-154.9],[193.6,-154.9]]).appendPoint([193.6,-141.1]).appendPoint([179.8,-141.1]).appendPoint([179.8,-154.9]).close().innerToCAG()
).union(
    new CSG.Path2D([[179.8,-174.1],[193.6,-174.1]]).appendPoint([193.6,-160.3]).appendPoint([179.8,-160.3]).appendPoint([179.8,-174.1]).close().innerToCAG()
))).extrude({ offset: [0, 0, 1.2] });
}




                function mounting_plate_case_fn() {
                    

                // creating part 0 of case mounting_plate
                let mounting_plate__part_0 = outline_with_holes_extrude_1_2_outline_fn();

                // make sure that rotations are relative
                let mounting_plate__part_0_bounds = mounting_plate__part_0.getBounds();
                let mounting_plate__part_0_x = mounting_plate__part_0_bounds[0].x + (mounting_plate__part_0_bounds[1].x - mounting_plate__part_0_bounds[0].x) / 2
                let mounting_plate__part_0_y = mounting_plate__part_0_bounds[0].y + (mounting_plate__part_0_bounds[1].y - mounting_plate__part_0_bounds[0].y) / 2
                mounting_plate__part_0 = translate([-mounting_plate__part_0_x, -mounting_plate__part_0_y, 0], mounting_plate__part_0);
                mounting_plate__part_0 = rotate([0,0,0], mounting_plate__part_0);
                mounting_plate__part_0 = translate([mounting_plate__part_0_x, mounting_plate__part_0_y, 0], mounting_plate__part_0);

                mounting_plate__part_0 = translate([0,0,0], mounting_plate__part_0);
                let result = mounting_plate__part_0;
                
            
                    return result;
                }
            
            
        
            function main() {
                return mounting_plate_case_fn();
            }

        
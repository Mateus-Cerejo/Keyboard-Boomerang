function outline_extrude_1_2_outline_fn(){
    return new CSG.Path2D([[285.8,-111.6],[338.4,-111.6]]).appendPoint([338.4,-92.4]).appendPoint([357.6,-92.4]).appendPoint([357.6,-69.2]).appendPoint([338.4,-69.2]).appendPoint([338.4,-50]).appendPoint([257.6,-50]).appendPoint([257.6,-69.2]).appendPoint([238.4,-69.2]).appendPoint([238.4,-117.2]).appendPoint([205.7,-117.2]).appendPoint([205.7,-178.8]).appendPoint([228.9,-178.8]).appendPoint([228.9,-140.4]).appendPoint([285.8,-140.4]).appendPoint([285.8,-111.6]).close().innerToCAG()
.union(
    new CSG.Path2D([[65.6,-111.6],[118.2,-111.6]]).appendPoint([118.2,-140.4]).appendPoint([175.1,-140.4]).appendPoint([175.1,-178.8]).appendPoint([198.3,-178.8]).appendPoint([198.3,-117.2]).appendPoint([165.6,-117.2]).appendPoint([165.6,-69.2]).appendPoint([146.4,-69.2]).appendPoint([146.4,-50]).appendPoint([65.6,-50]).appendPoint([65.6,-69.2]).appendPoint([46.4,-69.2]).appendPoint([46.4,-92.4]).appendPoint([65.6,-92.4]).appendPoint([65.6,-111.6]).close().innerToCAG()
).extrude({ offset: [0, 0, 1.2] });
}




                function outline_case_fn() {
                    

                // creating part 0 of case outline
                let outline__part_0 = outline_extrude_1_2_outline_fn();

                // make sure that rotations are relative
                let outline__part_0_bounds = outline__part_0.getBounds();
                let outline__part_0_x = outline__part_0_bounds[0].x + (outline__part_0_bounds[1].x - outline__part_0_bounds[0].x) / 2
                let outline__part_0_y = outline__part_0_bounds[0].y + (outline__part_0_bounds[1].y - outline__part_0_bounds[0].y) / 2
                outline__part_0 = translate([-outline__part_0_x, -outline__part_0_y, 0], outline__part_0);
                outline__part_0 = rotate([0,0,0], outline__part_0);
                outline__part_0 = translate([outline__part_0_x, outline__part_0_y, 0], outline__part_0);

                outline__part_0 = translate([0,0,0], outline__part_0);
                let result = outline__part_0;
                
            
                    return result;
                }
            
            
        
            function main() {
                return outline_case_fn();
            }

        